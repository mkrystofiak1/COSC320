//Program: main.cpp
//Author: Mitchell Krystofiak
//Description: Testing algorithm for:
//	       - Depth First Search (DFS)
//	       - Topological Sort
//	       - Adding Vertices/Edges
//	       - Adjacency List Printing (if time permits)
//	       - Directed Acyclic Graphs (DAG)
//Date: April 28, 2021

#include <iostream>
#include "graph.h"

using namespace std;

int main()
{
	Graph<int> G(UNDIRECTED);
	Graph<int> H(DIRECTED);
	cout << "--------------------------------------------------" << endl;
	cout << "We will test the capabilities of the program using" << endl;
	cout << "an undirected graph (G) and a directed graph (H). " << endl;
	cout << "--------------------------------------------------" << endl;
	cout << endl;
	cout << "-------------------------------------------" << endl;
	cout << "Testing getGraphType(), which returns 0 for" << endl;
	cout << "undirected and 1 for directed.             " << endl;
	cout << "-------------------------- ----------------" << endl;
	cout << endl;

	cout << "Graph G is ";
	if (G.getGraphType() == 0)
		cout << "Undirected." << endl;
	cout << "Graph H is ";
	if (H.getGraphType() == 1)
		cout << "Directed." << endl;
	cout << endl;

	cout << "--------------------" << endl;
	cout << "Testing addVertex()." << endl;
	cout << "--------------------" << endl;
	cout << endl;
	cout << "Adding 8 vertices, 1 - 8. " << endl;	
	for (int i = 1; i <= 8; i++)
	{
		G.addVertex(i);
		H.addVertex(i);
	}
	cout << "Graph G: " << endl;
	G.print();
	cout << endl;
	cout << "Graph H: " << endl;
	H.print();
	cout << endl;

	cout << "----------------------------------" << endl;
	cout << "Testing adding duplicate vertices." << endl;
	cout << "----------------------------------" << endl;
	cout << endl;
	cout << "Graph G: " << endl;
	G.addVertex(7);
	G.addVertex(2);
	G.addVertex(8);
	cout << endl;
	cout << "Graph H: " << endl;
	H.addVertex(7);
	H.addVertex(2);
	H.addVertex(8);
	cout << endl;

	cout << "------------------" << endl;
	cout << "Testing addEdge()." << endl;
	cout << "------------------" << endl;
	cout << endl;
	G.addEdge(1,2);
	G.addEdge(1,1);
	G.addEdge(1,5);
	G.addEdge(1,6);
	G.addEdge(6,3);
	G.addEdge(3,4);
	G.addEdge(4,8);
	G.addEdge(3,7);
	G.addEdge(7,4);
	cout << "Graph G: " << endl;
	G.print();
	cout << endl;
	H.addEdge(1,2);
	H.addEdge(1,5);
	H.addEdge(5,6);
	H.addEdge(6,3);
	H.addEdge(3,4);
	H.addEdge(3,7);
	H.addEdge(7,8);
	cout << "Graph H: " << endl;
	H.print();
	cout << endl;
	cout << "Notice how H is directed, and acyclic, or a DAG, for the sake of topological sort!" << endl;
	cout << "Also notice how the edges in G reciprocate because they are undirected and how the" << endl;
	cout << "edges in H don't." << endl;
	cout << endl;

	cout << "-------------------------------" << endl;
	cout << "Testing adding duplicate edges." << endl;
	cout << "-------------------------------" << endl;
	cout << endl;
	cout << "Graph G: " << endl;
	G.addEdge(1,2);
	G.addEdge(1,5);
	cout << endl;
	cout << "Graph H: " << endl;
	H.addEdge(1,2);
	H.addEdge(1,5);
	cout << endl;

	cout << "---------------------------" << endl;
	cout << "Testing Depth First Search." << endl;
        cout << "---------------------------" << endl;	
	cout << endl;
	cout << "Graph G: " << endl;
	G.printDFS(1);
	cout << endl;
	cout << "Graph H: " << endl;
	H.printDFS(1);
	cout << endl;

	cout << "-------------------------" << endl;
	cout << "Testing Topological Sort." << endl;
	cout << "-------------------------" << endl;
	cout << endl;
	cout << "Graph G: " << endl;
	G.topSortPrint();
	cout << endl;
	cout << "Graph H: " << endl;
	H.topSortPrint();
	cout << endl;

	cout << "--------------------------------------" << endl;
	cout << "Testing Strongly Connected Components." << endl;
	cout << "--------------------------------------" << endl;
	cout << endl;
	cout << "Graph G: " << endl;
	G.SCCprint();
	cout << endl;
	cout << "Graph H: " << endl;
	H.SCCprint();
	cout << endl;







	return 0;
}
